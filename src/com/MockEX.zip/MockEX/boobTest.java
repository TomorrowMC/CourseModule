package com.MockEX;

/**
 * @author Yifei.Hu
 * @create 2021-11--20:36
 */
public class boobTest {
    public static void main(String[] args) {

        System.out.println("iamhuyifei,today,iamapig,apiiiiiiiig,abiiiiiiiigpiiiiiiig!!!!!!!!!");
    }
}
